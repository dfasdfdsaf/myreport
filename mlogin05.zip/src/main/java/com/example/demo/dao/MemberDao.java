package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.entity.*;

@Mapper
public interface MemberDao {
	@Insert("insert into member(username,password,irum,email,birthday) values(#{username}, #{password}, #{irum}, #{email}, #{birthday})")
	public Integer save(Member member);
	
	@Select("select * from member where username=#{username} and rownum<=1")
	public Optional<Member> findById(String username);
	
	@Update("update member set loginFailCnt=loginFailCnt+1 where username=#{username}")
	public void increaseLoginFailCnt(String username);
	
	@Update("update member set loginFailCnt=0 where username=#{username}")
	public void resetLoginFailCnt(String username);
	
	@Update("update member set enabled=0 where username=#{username}")
	public void block(String username);
}






