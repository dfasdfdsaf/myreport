package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

@Mapper
public interface RoleDao {
	@Insert("insert into role values(#{username}, #{rolename})")
	public Integer save(String username, String rolename);
	
	@Select("select rolename from role where username=#{username}")
	public List<String> findByUsername(String username);
}
