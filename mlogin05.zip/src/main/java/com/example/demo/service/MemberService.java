package com.example.demo.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.crypto.password.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

@Service
public class MemberService {
	@Autowired
	private MemberDao memberDao;
	@Autowired
	private RoleDao roleDao;
	@Autowired
	private PasswordEncoder passwordEncoder;

	
	// join 작업은 sql이 2개 - member 저장, role 저장
	// 작업의 일부가 실패하면 전체를 취소
	// Transaction : 하나의 작업으로 처리해야 하는 일련의 sql
	@Transactional
	public void join(Member member) {
		member.setPassword(passwordEncoder.encode(member.getPassword()));
		// 사용자 정보 저장
		memberDao.save(member);
		// 기본 권한은 USER
		roleDao.save(member.getUsername(), "ROLE_USER");
	}
}




