package com.example.demo.controller;

import javax.validation.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.access.annotation.*;
import org.springframework.security.access.prepost.*;
import org.springframework.stereotype.*;
import org.springframework.validation.*;
import org.springframework.validation.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.*;
import com.example.demo.service.*;

@Validated
@Controller
public class MemberController {
	@Autowired
	private MemberService service;
	
	// 루트 페이지
	@GetMapping({"/", "/index"})
	public String index() {
		return "/index";
	}
	
	// 회원 가입
	@PreAuthorize("isAnonymous()")
	@GetMapping("/join")
	public String join() {
		return "/join";
	}
	
	@PreAuthorize("isAnonymous()")
	@PostMapping("/join")
	public String join(@Valid Member member, BindingResult bindingResult) {
		service.join(member);
		return "/login";
	}
	
	// 비로그인 접근 가능 페이지
	@PreAuthorize("isAnonymous()")
	@GetMapping("/find")	
	public String find() {
		return "/find";
	}
	
	// 로그인 접근 가능 페이지
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/write")
	public String write() {
		return "/write";
	}
	
	// 403을 발생 ->  AccessDeniedHandler -> /index?error=403
	@Secured("ROLE_ADMIN")
	@GetMapping("/admin")
	public String admin() {
		return "/admin";
	}
}
