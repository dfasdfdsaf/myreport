package com.example.demo.security;

import java.util.*;

import org.springframework.security.core.*;
import org.springframework.security.core.userdetails.*;

import lombok.*;

// UserDetails : 사용자 정보와 권한 정보를 저장하는 표준
// UserDetailsService : DB에서 읽어와 UserDetails를 생성하는 표준

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Account implements UserDetails {
	// username, password, 권한 목록, 
	private String username;
	private String password;
	private Boolean enabled;
	
	// ArrayList -> List -> Collection
	// HashMap -> Map ->	Collection
	@Getter
	private Collection<GrantedAuthority> authorities;
	
	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return enabled;
	}
}
