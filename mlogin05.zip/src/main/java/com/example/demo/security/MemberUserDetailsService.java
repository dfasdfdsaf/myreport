package com.example.demo.security;

import java.util.*;
import java.util.stream.*;

import org.springframework.security.core.*;
import org.springframework.security.core.authority.*;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

import lombok.*;

@RequiredArgsConstructor
@Service
public class MemberUserDetailsService implements UserDetailsService {
	private final MemberDao memberDao;
	private final RoleDao roleDao;
	
	@Transactional(readOnly=true)
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Member member = memberDao.findById(username).orElseThrow(()->new UsernameNotFoundException("not found"));
		
		Account account = Account.builder().username(member.getUsername())
					.password(member.getPassword()).enabled(member.getEnabled()).build();
		
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		List<String> list = roleDao.findByUsername(username);
		for(String str:list) {
			authorities.add(new SimpleGrantedAuthority(str));
		}
		account.setAuthorities(authorities);
		return account;
	}
}


