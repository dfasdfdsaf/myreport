package com.example.demo.security;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.security.core.*;
import org.springframework.security.web.*;
import org.springframework.security.web.authentication.*;
import org.springframework.security.web.savedrequest.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

import lombok.*;

@Component
public class LoginFailHandler extends SimpleUrlAuthenticationFailureHandler {
	@Autowired
	private MemberDao dao;
	
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
		AuthenticationException exception) throws IOException, ServletException {
		// 1. 로그인에 실패한 아이디를 가지고 온다
		// 2. 사용자 정보를 읽어온다
		// 3. 로그인 실패 횟수가 4회라면 1증가 시키고 블록한 다음 이동
		// 4. 로그인 실패 횟수가 3회이하라면 1증가 시키고 이동
		// "로그인에 3회 실패했습니다" 또는 "로그인에 5회실패해 계정이 블록되었습니다"
		// 와 같은 오류 메시지를 가지고 루트로 보내자
		
		// 아이디가 틀렸을 수도 있고, 비밀번호가 틀렸을 수도 있다
		String username = request.getParameter("username");
		Member member = dao.findById(username).orElse(null);
		
		// 41라인 if문은 아이디가 틀렸니? 비밀번호가 틀렸니? 에 대한 if
		RedirectStrategy rs = new DefaultRedirectStrategy();
		if(member==null) {
			rs.sendRedirect(request,response,"/index?error=username");
		} else {
			// 4회 틀렸다면 5회로 세팅하고 계정을 새로 비활성화
			if(member.getLoginFailCnt()==4) {
				dao.increaseLoginFailCnt(username);
				dao.block(username);
				rs.sendRedirect(request,response,"/index?error=block");
			} else if(member.getLoginFailCnt()<=3) {
				// 3회이하로 틀렸다면 실패횟수가 증가
				dao.increaseLoginFailCnt(username);
				rs.sendRedirect(request,response,"/index?error=increase");
			} else
				// 이미 계정이 비활성화 상태
				rs.sendRedirect(request,response,"/index?error=block");
		}
	}
}




